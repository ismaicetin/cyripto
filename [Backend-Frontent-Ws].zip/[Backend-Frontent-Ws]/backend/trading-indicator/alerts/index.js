module.exports = {
    ...require('./bollinger_band.js'),
    ...require('./ema.js'),
    ...require('./sma.js'),
    ...require('./rsi.js'),
}