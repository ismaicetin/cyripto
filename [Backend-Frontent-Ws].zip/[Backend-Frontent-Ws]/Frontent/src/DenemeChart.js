// import React, { useEffect, useRef } from "react";
// import Highcharts from "highcharts";

// export default function DenemeChart({ data = [], debug = false }) {
// 	const inputEl = useRef();

// 	let chart;

// 	useEffect(() => {
// 		chart = Highcharts.chart(inputEl.current, {
// 			title: {
// 				text: "Solar Employment Growth by Sector, 2010-2016",
// 			},

// 			subtitle: {
// 				text: "Source: thesolarfoundation.com",
// 			},

// 			yAxis: {
// 				title: {
// 					text: "Number of Employees",
// 				},
// 			},

// 			legend: {
// 				layout: "vertical",
// 				align: "right",
// 				verticalAlign: "middle",
// 			},

// 			plotOptions: {
// 				series: {
// 					label: {
// 						connectorAllowed: false,
// 					},
// 				},
// 			},

// 			series: [
// 				{
// 					name: "Installation",
// 					data: data,
// 				},
// 			],

// 			responsive: {
// 				rules: [
// 					{
// 						condition: {
// 							maxWidth: 500,
// 						},
// 						chartOptions: {
// 							legend: {
// 								layout: "horizontal",
// 								align: "center",
// 								verticalAlign: "bottom",
// 							},
// 						},
// 					},
// 				],
// 			},
// 		});
// 		return () => {
// 			chart.destroy();
// 		};
// 	}, [data]);

// 	// useEffect(() => {
// 	// 	chart?.destroy();
// 	// 	chart = Highcharts.chart(inputEl.current, {
// 	// 		title: {
// 	// 			text: "Solar Employment Growth by Sector, 2010-2016",
// 	// 		},

// 	// 		subtitle: {
// 	// 			text: "Source: thesolarfoundation.com",
// 	// 		},

// 	// 		yAxis: {
// 	// 			title: {
// 	// 				text: "Number of Employees",
// 	// 			},
// 	// 		},

// 	// 		legend: {
// 	// 			layout: "vertical",
// 	// 			align: "right",
// 	// 			verticalAlign: "middle",
// 	// 		},

// 	// 		plotOptions: {
// 	// 			series: {
// 	// 				label: {
// 	// 					connectorAllowed: false,
// 	// 				},
// 	// 			},
// 	// 		},

// 	// 		series: [
// 	// 			{
// 	// 				name: "Installation",
// 	// 				data: data,
// 	// 			},
// 	// 		],

// 	// 		responsive: {
// 	// 			rules: [
// 	// 				{
// 	// 					condition: {
// 	// 						maxWidth: 500,
// 	// 					},
// 	// 					chartOptions: {
// 	// 						legend: {
// 	// 							layout: "horizontal",
// 	// 							align: "center",
// 	// 							verticalAlign: "bottom",
// 	// 						},
// 	// 					},
// 	// 				},
// 	// 			],
// 	// 		},
// 	// 	});
// 	// 	console.log(chart);
// 	// }, [data]);
// 	return (
// 		<div>
// 			{debug && <div>{JSON.stringify(data[0])}</div>}
// 			<div id="container" ref={inputEl}></div>
// 		</div>
// 	);
// }
import React, { useEffect } from "react";
import Highcharts from "highcharts";

const Bar = ({ data, categories, name, backgroundColor }) => {
	const getdate = (value) => {
		let date = new Date(value);

		var dateStr =
			("00" + (date.getMonth() + 1)).slice(-2) +
			"/" +
			("00" + date.getDate()).slice(-2) +
			"/" +
			date.getFullYear() +
			" " +
			("00" + date.getHours()).slice(-2) +
			":" +
			("00" + date.getMinutes()).slice(-2) +
			":" +
			("00" + date.getSeconds()).slice(-2);
		return dateStr;
	};

	useEffect(() => {
		// Highcharts.chart("container", {
		// 	chart: {
		// 		type: "line",
		// 		backgroundColor,
		// 	},
		// 	colors: ["#FBD94F", "#0170F3"],
		// 	title: {
		// 		text: "Yearly Breakup",
		// 		// style: { color: "#0170F3", fontWeight: 900, fontSize: "20px" },
		// 	},
		// 	// xAxis: {
		// 	// 	categories,
		// 	// },
		// 	yAxis: {
		// 		min: 0,
		// 		title: {
		// 			text: "Amount",
		// 		},
		// 	},
		// 	tooltip: {
		// 		pointFormat:
		// 			'<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b> ({point.percentage:.0f}%)<br/>',
		// 		shared: true,
		// 	},
		// 	plotOptions: {
		// 		column: {
		// 			stacking: "percent",
		// 		},
		// 	},
		// 	series: data,
		// });

		Highcharts.chart(`container${name}`, {
			chart: {
				type: "line",
				height: 768,
				width: 1080,
			},
			title: {
				text: name,
			},

			xAxis: {
				categories: categories,
				labels: {
					formatter: function () {
						return getdate(this.value);
					},
				},
			},
			yAxis: {
				title: {
					text: "Number of Employees",
				},
				max: 100,
				min: 0,
				plotLines: [
					{
						color: "black",
						dashStyle: "dot",
						width: 3,
						value: 70,
						label: {
							align: "right",
							style: {
								fontStyle: "italic",
							},
							text: "Satım Yap",
							x: -10,
						},
						zIndex: 3,
					},
					{
						color: "red",
						dashStyle: "dot",
						width: 3,
						value: 30,
						label: {
							align: "right",
							style: {
								fontStyle: "italic",
							},
							text: "Alım Yap",
							x: -10,
						},
						zIndex: 3,
					},
				],
			},
			plotOptions: {
				spline: {
					marker: {
						enable: false,
					},
				},
			},
			tooltip: {
				formatter: function () {
					return `${getdate(this.x)} : <strong style=" color: red; ">${this.y}</strong>`;
				},
			},

			series: [
				{
					name: "Installation",
					data: data,
				},
			],
		});
	}, [name]);

	return <div id={`container${name}`}></div>;
};

export default Bar;
