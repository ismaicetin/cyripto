const ccxt = require("ccxt");

let intervaltoSince = {
	"1m": 1,
	"3m": 3,
	"5m": 5,
	"15m": 15,
	"30m": 30,
	"1h": 60,
	"2h": 2 * 60,
	"4h": 4 * 60,
	"6h": 6 * 60,
	"8h": 8 * 60,
	"12h": 12 * 60,
	"1d": 24 * 60,
	"3d": 3 * 24 * 60,
	"1w": 7 * 24 * 60,
	"1M": 30 * 24 * 60,
};
const getOHLCV = async (ex, ticker, interval, isFuture = false, since, limit) => {
	let d = new Date();
let settime =
	d.setMinutes(d.getMinutes() - intervaltoSince[interval] * since);

	if (!ccxt.exchanges.includes(ex)) {
		throw "Exchange is not supported";
	}
	try {
		let exchangeId = ex,
			exchangeClass = ccxt[exchangeId];

		let exchange;
		if (isFuture) {
			exchange = new exchangeClass({
				options: {
					defaultMarket: "future",
				},
			});
		} else {
			exchange = new exchangeClass({});
		}
		return await exchange.fetchOHLCV(ticker, interval, since, limit);
	} catch (err) {
		throw "Ticker is not supported";
	}
};
// console.log(getOHLCV("binance", "BTC/USDT", "15m", true))
module.exports = getOHLCV;
