import { useEffect, useState } from "react";

// import CoinGecko from "coingecko-api"; // https://github.com/miscavage/CoinGecko-API
// import { rsi } from "./trading-indicator/index"; //https://github.com/thanhnguyennguyen/trading-indicator
// const rsi = require("trading-indicator").rsi;
import logo from "./logo.svg";
import "./App.css";
import DenemeChart from "./DenemeChart";
// const ccxt = require("ccxt");
function App() {
	var wsUrl = location.origin.replace(/^http/, "ws");
	// let wsUrl = `ws://localhost:5000/?token=ismailcetin`;
	// let wsUrl = `ws://cyripto.herokuapp.com:8080/?token=ismailcetin`;
	let wsdataTemp = [];
	const [data, setdata] = useState([]);
	// const CoinGeckoClient = new CoinGecko();
	// const [rsiData, setrsiData] = useState([]);
	// const [category, setcategory] = useState([]);
	// const binance = new ccxt.binance();

	let sw;
	const runSocket = (_) => {
		console.log("runSocket");
		sw = new WebSocket(wsUrl);

		sw.onopen = function () {
			console.log("ws connected");
		};

		sw.onmessage = (msg) => {
			let msgdata = JSON.parse(msg.data);
			console.log(msgdata);
			let tempdata = { ...wsdataTemp, ...msgdata };
			wsdataTemp = tempdata;
			setdata(tempdata);
		};
		sw.onerror = (e) => {
			console.error("ws onerror");
			console.error(e);
			sw.close();
		};

		sw.onclose = (e) => {
			console.warn("ws onclose");
			console.warn(e);
			setTimeout(runSocket, 5000);
		};
	};

	const disableSocket = (_) => {
		sw.close();
		console.log("ws disableSocket");
	};

	useEffect(() => {
		// run();
		runSocket();
		return () => {
			disableSocket();
		};
	}, []);

	// const run = async () => {
	// 	// let a = await binance.fetchOHLCV("BTC/USDT", "4h", undefined, 10);
	// 	// console.log(a);
	// 	// debugger;

	// 	console.clear();
	// 	let data, category;
	// 	[data, category] = await rsi(14, "close", "binance", "CHZ/USDT", "4h", true);
	// 	console.log("rsi", data, category);
	// 	setrsiData(data);
	// 	setcategory(category);
	// 	//3. Make calls
	// 	// data = await CoinGeckoClient.ping(); ////API sunucu durumunu kontrol edin.
	// 	// console.log("ping", data);
	// 	// data = await CoinGeckoClient.global(); //Küresel kripto para birimi verilerini alın.
	// 	// console.log("global", data);
	// 	// data = await CoinGeckoClient.coins.all(); //Tüm kripto paraları verilerle (isim, fiyat, pazar, geliştirici, topluluk, vb.) Listeleyin - 50 ile sayfalandırılmış.
	// 	// console.log("coins.all", data);
	// 	// data = await CoinGeckoClient.coins.list(); //API çağrıları yapmak için tüm paraların kimliğini almak için bunu kullanın
	// 	// console.log("coins.list", data);
	// 	// data = await CoinGeckoClient.coins.markets(); //Tüm madeni para piyasa verilerini (fiyat, piyasa değeri, hacim) elde etmek için bunu kullanın.
	// 	// console.log("coins.markets", data);
	// 	// data = await CoinGeckoClient.coins.fetch("bitcoin", {}); //Bir jeton için güncel verileri (isim, fiyat, pazar,… takas fişleri dahil) alın.
	// 	// console.log("coins.fetch", data);
	// 	// data = await CoinGeckoClient.coins.fetchTickers("bitcoin"); //Madeni para şeritleri alın (100 maddeye bölünmüş olarak).
	// 	// console.log("coins.fetchTickers", data);
	// 	// data = await CoinGeckoClient.coins.fetchHistory("bitcoin", { date: "30-12-2017" }); //Bir madeni para için belirli bir tarihte geçmiş verileri (isim, fiyat, piyasa, istatistikler) alın.
	// 	// console.log("coins.fetchHistory", data);
	// 	// data = await CoinGeckoClient.coins.fetchMarketChart("bitcoin"); //Fiyat, piyasa değeri ve 24 saatlik hacmi (ayrıntı düzeyi otomatik) içeren geçmiş piyasa verilerini alın.
	// 	// console.log("coins.fetchMarketChart", data);
	// 	// data = await CoinGeckoClient.coins.fetchMarketChartRange("bitcoin", {
	// 	// 	from: 13925,
	// 	// 	to: 1422577232,
	// 	// }); //Tarihsel piyasa verilerini alın, fiyat, piyasa değeri ve bir zaman damgası aralığında (ayrıntı düzeyi otomatik) 24 saatlik hacmi içerir. Dakikalık veriler 1 gün içinde kullanılacaktır. Saatlik veriler 1 gün ile 90 gün arasındaki süre için kullanılacaktır. Günlük veriler, 90 günün üzerindeki süre boyunca kullanılacaktır.
	// 	// console.log("coins.fetchMarketChartRange", data);
	// 	// data = await CoinGeckoClient.coins.fetchStatusUpdates("bitcoin"); //Belirli bir jeton için durum güncellemelerini alın.
	// 	// console.log("coins.fetchStatusUpdates", data);
	// 	// data = await CoinGeckoClient.exchanges.all(); //Borsalarla ilgili aramalar.
	// 	// console.log("exchanges.all", data);
	// 	// data = await CoinGeckoClient.exchanges.list(); //Desteklenen tüm pazarların kimliğini ve adını listeleyin (sayfalandırma gerekmez).
	// 	// console.log("exchanges.list", data);
	// 	// data = await CoinGeckoClient.exchanges.fetch("binance"); //Yalnızca belirli bir borsa için BTC cinsinden döviz hacmini ve en iyi 100 kuponu alın.
	// 	// console.log("exchanges.fetch", data);
	// 	// data = await CoinGeckoClient.exchanges.fetchTickers("binance"); //Belirli bir değişim için bilet  alın.
	// 	// console.log("exchanges.fetchTickers", data);
	// 	// data = await CoinGeckoClient.exchanges.fetchStatusUpdates("binance"); //Belirli bir değişim için durum güncellemelerini alın.
	// 	// console.log("exchanges.fetchStatusUpdates", data);
	// 	// data = await CoinGeckoClient.exchanges.fetchVolumeChart("binance", {
	// 	// 	days: 1,
	// 	// }); //BTC olarak döndürülen belirli bir borsa için hacim grafiği verilerini alın
	// 	// console.log("exchanges.fetchVolumeChart", data);
	// 	// data = await CoinGeckoClient.statusUpdates.all(); //
	// 	// console.log("statusUpdates.all", data);
	// 	// data = await CoinGeckoClient.events.all(); //
	// 	// console.log("events.all", data);
	// 	// data = await CoinGeckoClient.events.fetchCountries(); //
	// 	// console.log("events.fetchCountries", data);
	// 	// data = await CoinGeckoClient.events.fetchTypes(); //
	// 	// console.log("events.fetchTypes", data);
	// };

	return (
		<div className="App">
			<header className="App-header">
				<img src={logo} className="App-logo" alt="logo" />

				{Object.keys(data).map((item) => (
					<div style={{ paddingBottom: 15 }}>
						<DenemeChart
							name={item}
							data={data[item].data.slice(data[item].data.length - 15)}
							categories={data[item].category.slice(data[item].category.length - 15)}
							debug
						/>
					</div>
				))}
			</header>
		</div>
	);
}

export default App;
